void MatriceMoltiplicazione(float matrice[][DIM], float matrice2[][DIM], float matrice3[][DIM]);
void MatriceTrasposta(float matrice[][DIM], float matrice3[][DIM]);
void MatriceSomma(float matrice[][DIM], float matrice2[][DIM], float matrice3[][DIM]);
void ProdottoScalare(float matrice[][DIM], float matrice3[][DIM]);
