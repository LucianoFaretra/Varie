#include "DatiGlobali.h"
void ScrivereElemento(float matrice[][DIM], int i, int j, float valore);
float LetturaElemento(float matrice[][DIM], int i, int j);
