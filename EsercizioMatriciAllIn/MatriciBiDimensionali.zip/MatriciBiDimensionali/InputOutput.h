#include "DatiGlobali.h"

void InserimentoNumeroRigheEColonne(float matrice[][DIM], int n);
void ControlloMatrice(float matrice[][DIM], int n);
void InserimentoElementiMatrice(float matrice[][DIM], int n);
void StampaMatriceRisulta(float matrice[][DIM]);
float InserimentoScalare(void);
void CopiaIndici(float matrice[][DIM], float matrice3[][DIM]);
