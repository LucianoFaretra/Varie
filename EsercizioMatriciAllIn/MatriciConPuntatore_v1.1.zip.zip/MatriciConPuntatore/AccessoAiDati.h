void ScrivereElemento(float *matrice, int i, int j, float valore);
float LetturaElemento(float *matrice, int i, int j);
