void InserimentoNumeroRigheEColonne(float matrice[], int n);
void ControlloMatrice(float matrice[], int n);
void InserimentoElementiMatrice(float matrice[], int n);
void StampaMatriceRisulta(float matrice[]);
float InserimentoScalare(void);
void CopiaIndici(float matrice[], float matrice3[]);
