#define DIM 100
